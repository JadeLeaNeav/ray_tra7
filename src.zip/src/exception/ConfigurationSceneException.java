package exception;

public class ConfigurationSceneException extends Exception {

	public ConfigurationSceneException() {
		super();
	}
	
	public ConfigurationSceneException(String message) {
		super(message);
	}
	
}
