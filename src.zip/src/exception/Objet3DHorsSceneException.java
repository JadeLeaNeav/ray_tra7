package exception;

// import elements3D.Objet3D;

public class Objet3DHorsSceneException extends Exception {
	
	public Objet3DHorsSceneException() {
		super();
	}
	
	public Objet3DHorsSceneException(String message) {
		super(message);
	}

}
