package elements3D;

import rayTracing.Rayon;
import rayTracing.Scene;
import utilitaire.Point;
import utilitaire.Vecteur;
import exception.NomVideException;

import java.io.Serializable;

import rayTracing.Lumiere;

/**
 * Classe permettant d'utiliser / manipuler un plan pour le raytracing
 * @author tibo, en partenariat avec ses erreurs de programmation
 *
 */

public class Plan implements Objet3D, Serializable {
	
	private static final long serialVersionUID = 7303995654083808341L;
	private static int compteur = 0; // compteur pour les noms par d�faut

	/** Ensembles des proprietes du plan.*/
	private Materiau properties;
	
	/** Vecteur normal au plan*/
	private Vecteur normale;
	
	/** Point par lequel le plan passe*/
	private Point point;
	
	/** Nom du plan */
	private String nom;

	public Plan(Vecteur normale, Point point, String nom) throws NomVideException {
		if (NomVideException.estVide(nom)) {
			throw new NomVideException();
		}
		normale.normaliser();
		this.normale = normale.copie();
		this.point = point.copie();
		this.properties = new Materiau();
		this.nom = nom;
	}
	
	public Plan(Vecteur normale, Point point)  throws NomVideException { // ne devrait jamais throw l'exception en r�alit�
		this(normale, point, "Plan" + ++compteur);
	}
	
	public Plan(Vecteur normale, Point point, String nom, Materiau proprietes) throws NomVideException {
		if (NomVideException.estVide(nom)) {
			throw new NomVideException();
		}
		normale.normaliser();
		this.normale = normale.copie();
		this.point = point.copie();
		this.properties = proprietes;
		this.nom = nom;
	}
	
	//----------------------------------------------------------------------
	
	// Methodes get
	
	@Override
	public Propriete getMateriau(int num) {
		assert 0 <= num && num < Materiau.NB_PROPRIETES;
		return this.properties.getMateriau(num);
	}
	
	@Override
	public String getNom() {
		return this.nom;
	}
	
	public Point getPoint() {
		return this.point;
	}
	
	public Vecteur getNormale() {
		return this.normale;
	}
	
	/** Renvoie le point le plus proche du centre de la scene (0, 0, 0)
	 * On va partir du centre et se deplacer selon la normale du plan pour trouver ce point
	 */
	@Override
	public Point getPosition() {
		Vecteur translation = this.normale.copie();
		Point centreScene = new Point(0,0,0);
		
		//On teste si la normale est dans le bon sens pour la translation
		Vecteur pointPlanVersCentreScene = new Vecteur(this.point, new Point(0,0,0));
		if (pointPlanVersCentreScene.produitScalaire(translation) > 0) {
			translation.multiplication(-1);
		}
		
		//On cree un rayon qui passe par le centre de la scene et qui va vers le plan,
		//et paf ! �a fait des chocapics !
		return this.estTraversePar(new Rayon(translation, centreScene));
	}
	
	/**
	 * Retourne la normale au point d'impact et aussi son sens grace au rayon
	 * @param impact : Point d'impact du rayon qui appartient au plan
	 * @param rayon : rayon qui va peruter le plan
	 */
	@Override
	public Vecteur getNormal(Point impact, Rayon rayon) {
		assert impact != null && rayon != null;
		//Assert impact appartient au plan
		Vecteur vPtPlanPtImpact = new Vecteur(impact, this.point);
		if (Math.abs(vPtPlanPtImpact.produitScalaire(this.normale)) > Objet3D.EPSILON) {
			System.out.println("Le point d'impact n'appartient pas au plan");
			return null;
		}
		
		Vecteur direction = rayon.getDirection();
		double dot = direction.produitScalaire(this.normale);
		Vecteur retour = new Vecteur(this.normale.getX(), this.normale.getY(), this.normale.getZ());
		

		if (dot > 0) {
			retour.multiplication(-1);
		}
		return retour;
	}
	
	/**
	 * Retourne true si l'objet se fait de l'ombre lui meme
	 * @param impact : Point d'impact du rayon qui appartient au plan
	 * @param rayon : rayon qui va percuter le plan
	 * @param lumiere : Lumiere de la scene
	 **/
	@Override
	public boolean getSelfOmbre(Point impact, Rayon rayon, Lumiere lumiere) {
		assert impact != null && rayon != null && lumiere != null;
		//Assert impact appartient au plan
		Vecteur vPtPlanPtImpact = new Vecteur(impact, this.point);
		if (Math.abs(vPtPlanPtImpact.produitScalaire(this.normale)) > Objet3D.EPSILON) {
			System.out.println("Le point d'impact n'appartient pas au plan");
			return false;
		}
		
		Vecteur directionRayon = rayon.getDirection();
		double dotRayon = directionRayon.produitScalaire(this.normale);
		
		Vecteur directionLumiere = new Vecteur(lumiere.getCentre(), this.point);
		double dotLumiere = directionLumiere.produitScalaire(this.normale);
		
		return !(Math.signum(dotLumiere) == Math.signum(dotRayon));
	}
	
	
	//----------------------------------------------------------------------
	//Autres methodes

	/** http://nguyen.univ-tln.fr/share/Infographie3D/trans_raytracing.pdf
	 * Determine sir le plan est traverse par un rayon
	 * @param r : rayon
	 */
	@Override
	public Point estTraversePar(Rayon r) {
		assert r != null;
		double a,b,c,d,i,j,k,originerx,originery,originerz;
		a = this.normale.getX();
		b = this.normale.getY();
		c = this.normale.getZ();
		d = -( a*point.getX() + b*point.getY() + c*point.getZ() );
		
		i = r.getDirection().getX();
		j = r.getDirection().getY();
		k = r.getDirection().getZ();
		
		originerx = r.getOrigine().getX();
		originery = r.getOrigine().getY();
		originerz = r.getOrigine().getZ();
		
		double denominateur = a*i + b*j + c*k;
		if (Math.abs(denominateur) < Objet3D.EPSILON) {
			//System.out.println("Rayon est parallele au plan");
			return null;
		}
		double t = -(a*originerx + b*originery + c*originerz + d) / denominateur;
		if (t < 0) {
			//System.out.println("Le plan est pas dans le sens du vecteur");
			return null;
		}
		
		Point pointDeCollision = new Point(originerx,originery,originerz);
		pointDeCollision.translater(r.getDirection().multiplication(t));
		if (pointDeCollision.equals(r.getOrigine(), 0.001)) {
			return null;
		} else {
			return pointDeCollision;
		}
	}

	/** Determine la direction et sens du rayon reflechi contre le plan au point d'impact p
	 * @param r : rayon allant frapper le plan
	 * @param p : ici inutile puisque la direction de reflexion ne depend pas du point d'impact
	 * pour un plan
	 */
	@Override
	public Vecteur directionReflexion(Rayon r, Point p) {
		assert r != null && p != null;
		Vecteur projection = new Vecteur(r.getDirection().getX(),r.getDirection().getY(),r.getDirection().getZ());
		projection.retirerProjection(this.normale);
		
		Vecteur dirReflexion = r.getDirection().soustraire(projection.multiplication(2));
		dirReflexion = dirReflexion.soustraire(dirReflexion.multiplication(2));
		return dirReflexion;
	}
	
	/** Determine la direction et sens du rayon refracte contre le plan au point d'impact p
	 * @param r : rayon allant frapper le plan
	 * @param p : ici inutile puisque la direction de reflexion ne depend pas du point d'impact
	 * pour un plan
	 */
	//@Override
	public Vecteur directionRefraction(Rayon r, Point p, double indiceRefractionExterieur) {
		return r.getDirection(); // un plan n'engendre pas de refraction
	}
	
	/** Determine la direction et sens du rayon refracte contre le plan au point d'impact p
	 * @param r : rayon allant frapper le plan
	 * @param nObjet : Indice de réfraction de l'objet
	 * @param exterieurVersInterieur : sert a savoir dans quel sens s'effectue la refraction
	 * Cette fonction va servir pour les autres objets
	 * 
	 */
	public Vecteur directionRefraction(Rayon r, double nObjet, Boolean exterieurVersInterieur, double indiceRefractionExterieur) {
		double n1, n2, i1, i2;
		if (exterieurVersInterieur) {
			n1 = indiceRefractionExterieur;
			n2 = nObjet;
		} else {
			n1 = nObjet;
			n2 = indiceRefractionExterieur;
		}
		//System.out.println("indice interieur : "+nObjet + "      indice exterieur : "+ indiceRefractionExterieur);
		
		Vecteur normaleImpact = this.normale.copie();
		//Si la normale est pas dans le bon sens on la retourne
		if (this.normale.produitScalaire(r.getDirection()) > 0) {
			normaleImpact = normaleImpact.multiplication(-1);
		}
		
		i1 = r.getDirection().produitScalaire(normaleImpact.multiplication(-1)) / ( r.getDirection().module() * normaleImpact.module() );
		i1 = Math.acos(i1);
		
		//On obtient i2
		double angleRefTotale = Math.asin(n2/n1);
		if (n2 < n1 & i1 > angleRefTotale) {
			//Il y a reflexion totale
			return null;
		}
		i2 = Math.asin( (n1/n2) * Math.sin(i1) );
		
		//Si on a pas de reflexion totale alors on calcule & retourne le rayon refracte
		Vecteur axeRotation = r.getDirection().produitVectoriel(normaleImpact);
		axeRotation.normaliser();
		
		Vecteur directionRefraction = normaleImpact.multiplication(-1);
		directionRefraction = directionRefraction.rotationAxe(axeRotation, i2);
		
		return directionRefraction;
		
	}

	
	/**Translate le plan de dx, dy, dz
	 * @param dx,dy,dz : De combien sur chaque axe le plan va etre translate
	 */
	@Override
	public void translater(double dx, double dy, double dz) {
		this.point.translater(dx, dy, dz);
	}
	
	/**Effectue une rotation autour des axes x, y, z classiques
	 * @param rx : premiere roation effectuee
	 * @param ry : deuxieme roation effectuee
	 * @param rz : troisieme roation effectuee
	 */
	@Override
	public void rotation(double rx, double ry, double rz) {
		this.normale.rotationXYZ(rx,ry,rz);
	}
	
	/**Effectue une rotation autour d'un axe donne en entree
	 * @param rx : premiere roation effectuee
	 * @param ry : deuxieme roation effectuee
	 * @param rz : troisieme roation effectuee
	 */
	public void rotation(Point centre,double rx, double ry, double rz, Vecteur AxeX, Vecteur AxeY, Vecteur AxeZ) {
		this.normale = this.normale.rotationAxe(AxeX, rx);
		this.normale = this.normale.rotationAxe(AxeY, ry);
		this.normale = this.normale.rotationAxe(AxeZ, rz);
		
		this.point = this.point.rotationAxe(AxeX, centre, rx);
		this.point = this.point.rotationAxe(AxeY, centre, ry);
		this.point = this.point.rotationAxe(AxeZ, centre, rz);
	}

	/**
	 * Attribut un nom au plan
	 * @param nom : mon instinct me dit que ce parametre designe le nom de l'objet
	 */
	@Override
	public void setNom(String nom) throws NomVideException {
		if (NomVideException.estVide(nom)) {
			throw new NomVideException();
		}
		this.nom = nom;
	}
	
	/**
	 * Affiche les attributs du plan dans la console
	 */
	@Override
	public String toString() {
		return "Plan(" + this.nom + ")@(" + this.point.getX() + ", " + this.point.getY() + ", " + this.point.getZ() + ") de normale : (" + this.normale.getX() + ", " + this.normale.getY() + ", " + this.normale.getZ() + ")";
	}
	
	/**
	 * Retourne la copie du plan pour la robustesse
	 */
	public Plan copie() {
		Plan copie = null;
		try {
			copie = new Plan(this.normale, this.point, this.nom, this.properties);
		} catch (NomVideException e) {
			// ne devrait pas arriver
		}
		return copie;
	}

	@Override
	public boolean estHorsScene(double dimension, Point centre) {
		return false;
	}
	
	public void setPoint(Point point) {
		this.point = point;
	}

}
