/**
 * 
 */
package elements3D;

import java.io.Serializable;
import java.util.ArrayList;

import rayTracing.Rayon;
import utilitaire.Vecteur;
import utilitaire.Point;

/**
 * @author Christophe
 */
public class Refraction implements Propriete, Serializable {

	private static final long serialVersionUID = -1287556454361523445L;
	
	private double indiceRefractionInterieur;
	private double indiceRefractionExterieur;
	private double intensite; // entre 0 et 1 (1 = r�fl�chit tout)
	private double energie; // entre 0 et 1 
	private boolean on;
	
	public Refraction(double indice, double intensite, boolean on) {
		assert (0 <= intensite  && intensite <= 1);
		assert (1 <= indice);
		this.indiceRefractionInterieur = indice;
		this.indiceRefractionExterieur = 1;
		this.intensite = intensite;
		this.energie = 0;
		this.on = on;
	}
	
	@Override
	public boolean isOn() {
		// TODO Auto-generated method stub
		return on;
	}

	@Override
	public void reset() {
		// TODO Auto-generated method stub

	}
	
	public void setOn(boolean on) {
		this.on = on;
	}
	
	@Override
	public double getEnergie() {
		return this.energie;
	}
	
	public double getIndiceInterieur() {
		return this.indiceRefractionInterieur;
	}
	
	public void setIndiceInterieur(double indice) {
		assert (1 <= indice);
		this.indiceRefractionInterieur = indice;
		
	}
	
	public double getIndiceExterieur() {
		return this.indiceRefractionExterieur;
	}
	
	public void setIndiceExterieur(double indice) {
		assert (1 <= indice);
		this.indiceRefractionInterieur = indice;
		
	}
	
	public void setIntensite(double intensite) {
		assert (0 <= intensite  && intensite <= 1);
		this.intensite = intensite;
	}
	
	public void setEnergie(double energie) {
		assert (0 <= energie  && energie <= 1);
		this.energie = energie;
	}

	public ArrayList<Rayon> creerRayon(Rayon rayon, Point intersection, Objet3D objetIntersection) {
		assert (rayon != null && intersection != null && objetIntersection != null);
		Vecteur direction = objetIntersection.directionRefraction(rayon, intersection, indiceRefractionExterieur);
		ArrayList<Rayon> listeRayons = new ArrayList<Rayon>();
		listeRayons.add( new Rayon(direction, intersection, rayon, this.intensite, energie*rayon.getPartEnergie()) );
				// partEnergie � modifier 
		return listeRayons;
	}

}
