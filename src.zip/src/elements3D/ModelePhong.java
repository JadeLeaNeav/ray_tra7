package elements3D;

import java.io.Serializable;
import java.util.ArrayList;

import rayTracing.Rayon;
import utilitaire.Point;

public class ModelePhong implements Propriete, Serializable {
	
	private static final long serialVersionUID = 3175080915696036907L;
	
	// Sp�cularit�
	/** Coefficient de sp�cularit� d'un mat�riau pour le canal rouge.*/
	private double coeffSpeculaireR;
	/** Coefficient de sp�cularit� d'un mat�riau pour le canal vert.*/
	private double coeffSpeculaireG;
	/** Coefficient de sp�cularit� d'un mat�riau pour le canal bleu.*/
	private double coeffSpeculaireB;
	/** Brillance d'un mat�riau.
	 * Plus la brillance est grande, plus le mat�riau para�t lisse.*/
	private int brillance;
	private double importanceSpeculaire;
	
	// Ambiance
	/** Coefficient ambiant d'un mat�riau pour le canal rouge.*/
	private double coeffAmbiantR;
	/** Coefficient ambiant d'un mat�riau pour le canal vert.*/
	private double coeffAmbiantG;
	/** Coefficient ambiant d'un mat�riau pour le canal bleu.*/
	private double coeffAmbiantB;
	private double importanceAmbiante;
	
	// Diffusion
	/** Coefficient de diffusion d'un mat�riau pour le canal rouge.*/
	private double coeffDiffR;
	/** Coefficient de diffusion d'un mat�riau pour le canal vert.*/
	private double coeffDiffG;
	/** Coefficient de diffusion d'un mat�riau pour le canal bleu.*/
	private double coeffDiffB;
	private double importanceDiffusion;
	
	public ModelePhong() {
		this.coeffSpeculaireR = 0;
		this.coeffSpeculaireG = 0;
		this.coeffSpeculaireB = 0;
		this.brillance = 2;
		
		this.coeffAmbiantR = 0;
		this.coeffAmbiantG = 0;
		this.coeffAmbiantB = 0;
		
		this.coeffDiffR = 0;
		this.coeffDiffG = 0;
		this.coeffDiffB = 0;
		
		this.importanceDiffusion = 0;
		this.importanceAmbiante  = 0;
		this.importanceSpeculaire=0;
	}
	
	/** Le mod�le de Phong ne renvoit pas de rayon.*/
	@Override
	public boolean isOn() {
		return false;
	}

	@Override
	public void reset() {
		// TODO Auto-generated method stub
		
	}

	/** Le mod�le de Phong ne renvoit pas de rayon.*/
	@Override
	public void setOn(boolean on) {
		// TODO Auto-generated method stub
		
	}

	/** Le mod�le de Phong n'a pas d'�nergie.*/
	@Override
	public void setEnergie(double energie) {
		// TODO Auto-generated method stub
		
	}

	/** Le mod�le de Phong n'a pas d'�nergie.*/
	@Override
	public double getEnergie() {
		// TODO Auto-generated method stub
		return 0;
	}

	/** Le mod�le de Phong ne renvoit pas de rayon.*/
	@Override
	public ArrayList<Rayon> creerRayon(Rayon rayon, Point intersection, Objet3D objetIntersection) {
		// TODO Auto-generated method stub
		return null;
	}



	/** Obtenir le coefficient de sp�cularit� du mat�riau pour le canal rouge.
	 * 
	 * @return le coefficient de sp�cularit� du mat�riau pour le canal rouge
	 */
	public double getCoeffSpeculaireR() {
		return coeffSpeculaireR;
	}



	/** Modifier le coefficient de sp�cularit� du mat�riau pour le canal rouge.
	 * 
	 * @param coeffSpeculaireR le nouveau coefficient de sp�cularit� du mat�riau pour le canal rouge entre 0 et 1
	 */
	public void setCoeffSpeculaireR(double coeffSpeculaireR) {
		assert coeffSpeculaireR >= 0 & coeffSpeculaireR <= 1;
		this.coeffSpeculaireR = coeffSpeculaireR;
	}

	/** Obtenir le coefficient de sp�cularit� du mat�riau pour le canal vert.
	 * 
	 * @return le coefficient de sp�cularit� du mat�riau pour le canal vert
	 */
	public double getCoeffSpeculaireG() {
		return coeffSpeculaireG;
	}

	/** Modifier le coefficient de sp�cularit� du mat�riau pour le canal vert.
	 * 
	 * @param coeffSpeculaireG le nouveau coefficient de sp�cularit� du mat�riau pour le canal vert entre 0 et 1
	 */
	public void setCoeffSpeculaireG(double coeffSpeculaireG) {
		assert coeffSpeculaireG >= 0 & coeffSpeculaireG <= 1;
		this.coeffSpeculaireG = coeffSpeculaireG;
	}

	/** Obtenir la brillance du mat�riau.
	 * 
	 * @return la brillance du mat�riau
	 */
	public int getBrillance() {
		return brillance;
	}



	/** Modifier la brillance du mat�riau.
	 * 
	 * @param puissance entier sup�rieur � 1, brillance = 2**puissance
	 */
	public void setBrillance(int puissance) {
		assert brillance >= 1;
		this.brillance = (int)Math.pow(2, puissance);
	}



	/** Obtenir le coefficient de sp�cularit� du mat�riau pour le canal bleu.
	 * 
	 * @return le coefficient de sp�cularit� du mat�riau pour le canal bleu
	 */
	public double getCoeffSpeculaireB() {
		return coeffSpeculaireB;
	}



	/** Modifier le coefficient de sp�cularit� du mat�riau pour le canal bleu.
	 * 
	 * @param coeffSpeculaireB le nouveau coefficient de sp�cularit� du mat�riau pour le canal bleu entre 0 et 1
	 */
	public void setCoeffSpeculaireB(double coeffSpeculaireB) {
		assert coeffSpeculaireB >= 0 & coeffSpeculaireB <= 1;
		this.coeffSpeculaireB = coeffSpeculaireB;
	}



	/** Obtenir le coefficient ambiant du mat�riau pour le canal rouge.
	 * 
	 * @return le coefficient ambiant du mat�riau pour le canal rouge
	 */
	public double getCoeffAmbiantR() {
		return coeffAmbiantR;
	}



	/** Modifier le coefficient ambiant du mat�riau pour le canal rouge.
	 * 
	 * @param coeffAmbiantR le nouveau coefficient ambiant du mat�riau pour le canal rouge entre 0 et 1
	 */
	public void setCoeffAmbiantR(double coeffAmbiantR, Couleur ambiante) {
		assert coeffAmbiantR >= 0 & coeffAmbiantR <= 1;
		this.coeffAmbiantR = this.importanceAmbiante * ambiante.getRed();
	}



	/** Obtenir le coefficient ambiant du mat�riau pour le canal vert.
	 * 
	 * @return le coefficient ambiant du mat�riau pour le canal vert
	 */
	public double getCoeffAmbiantG() {
		return coeffAmbiantG;
	}



	/** Modifier le coefficient ambiant du mat�riau pour le canal vert.
	 * 
	 * @param coeffAmbiantR le nouveau coefficient ambiant du mat�riau pour le canal vert entre 0 et 1
	 */
	public void setCoeffAmbiantG(double coeffAmbiantG, Couleur ambiante) {
		assert coeffAmbiantG >= 0 & coeffAmbiantG <= 1;
		this.coeffAmbiantR = this.importanceAmbiante * ambiante.getGreen();
	}



	/** Obtenir le coefficient ambiant du mat�riau pour le canal bleu.
	 * 
	 * @return le coefficient ambiant du mat�riau pour le canal bleu
	 */
	public double getCoeffAmbiantB() {
		return coeffAmbiantB;
	}



	/** Modifier le coefficient ambiant du mat�riau pour le canal bleu.
	 * 
	 * @param coeffAmbiantB le nouveau coefficient ambiant du mat�riau pour le canal bleu entre 0 et 1
	 */
	public void setCoeffAmbiantB(double coeffAmbiantB, Couleur ambiante) {
		assert coeffAmbiantB >= 0 & coeffAmbiantB <= 1;
		this.coeffAmbiantB = this.importanceAmbiante * ambiante.getBlue();
	}



	/** Obtenir le coefficient de diffusion du mat�riau pour le canal rouge.
	 * 
	 * @return le coefficient de diffusion du mat�riau pour le canal rouge
	 */
	public double getCoeffDiffR() {
		return coeffDiffR;
	}



	/** Modifier le coefficient de diffusion du mat�riau pour le canal rouge.
	 * 
	 * @param coeffDiffR le nouveau coefficient de diffusion du mat�riau pour le canal rouge entre 0 et 1
	 */
	public void setCoeffDiffR(double coeffDiffR) {
		assert coeffDiffR >= 0 & coeffDiffR <= 1;
		this.coeffDiffR = coeffDiffR;
	}



	/** Obtenir le coefficient de diffusion du mat�riau pour le canal vert.
	 * 
	 * @return le coefficient de diffusion du mat�riau pour le canal vert
	 */
	public double getCoeffDiffG() {
		return coeffDiffG;
	}



	/** Modifier le coefficient de diffusion du mat�riau pour le canal vert.
	 * 
	 * @param coeffDiffG le nouveau coefficient de diffusion du mat�riau pour le canal vert entre 0 et 1
	 */
	public void setCoeffDiffG(double coeffDiffG) {
		assert coeffDiffG >= 0 & coeffDiffG <= 1;
		this.coeffDiffG = coeffDiffG;
	}



	/** Obtenir le coefficient de diffusion du mat�riau pour le canal bleu.
	 * 
	 * @return le coefficient de diffusion du mat�riau pour le canal bleu
	 */
	public double getCoeffDiffB() {
		return coeffDiffB;
	}



	/** Modifier le coefficient de diffusion du mat�riau pour le canal bleu.
	 * 
	 * @param coeffDiffB le nouveau coefficient de diffusion du mat�riau pour le canal bleu entre 0 et 1
	 */
	public void setCoeffDiffB(double coeffDiffB) {
		assert coeffDiffB >= 0 & coeffDiffB <= 1;
		this.coeffDiffB = coeffDiffB;
	}

}
