/**
 * 
 */
package elements3D;

import rayTracing .*;
import utilitaire .*;
import exception.NomVideException;

import java.io.Serializable;
import java.lang.Math;

/** Sphere est une implantation de l'interface Objet3D. Cette classe permet
 * de definir la forme 3D specifique d'une sphere � partir d'un ensemble de
 * propri�t�s materielles (couleur...), d'une origine (point) et d'un rayon
 * (distance � l'origine).
 * @author Edgar
 *
 */
public class Sphere implements Objet3D, Serializable {
	
	private static final long serialVersionUID = -5841917298616385596L;
	private static int compteur = 0; // compteur pour les noms par d�faut
	
	/** Ensembles des proprietes de la sphere.*/
	private Materiau properties;
	
	/** Nom de la sph�re */
	private String nom;
	
	/** Point d'origine de la sphere.*/
	private Point origine;
	
	/** Rayon de la sphere.*/
	private double rayon;
	
	// Couleur pour la lumi�re ambiante
	
	/**
	 * Creer une sphere � partir d'un point d'origine, d'un rayon et d'un nom
	 * @param origine : coordonnees du centre de la sphere
	 * @param rayon : rayon de la sphere
	 * @pre origine != null && rayon > 0.0
	 */
	public Sphere(Point origine, double rayon, String nom) throws NomVideException {
		assert origine != null && rayon > 0.0;
		if (NomVideException.estVide(nom)) {
			throw new NomVideException();
		}
		double x = origine.getX();
		double y = origine.getY();
		double z = origine.getZ();
		this.origine = new Point(x, y, z);
		this.rayon = rayon;
		this.properties = new Materiau();
		this.nom = nom;
	}
	
	/**
	 * Creer une sphere � partir d'un point d'origine et d'un rayon
	 * @param origine : coordonnees du centre de la sphere
	 * @param rayon : rayon de la sphere
	 * @pre origine != null && rayon > 0.0
	 */
	public Sphere(Point origine, double rayon) throws NomVideException { // ne devrait jamais throw l'exception en r�alit�
		this(origine, rayon, "Sphere" + ++compteur);
	}
	
	@Override
	public Point estTraversePar(Rayon r) {
		assert r != null;
		// le rayon se d�crit comme r = p + td, avec :
		// p origine de r
		double px = r.getOrigine().getX();
		double py = r.getOrigine().getY();
		double pz = r.getOrigine().getZ();
		 // d vect directeur de r
		double dx = r.getDirection().getX();
		double dy = r.getDirection().getY();
		double dz = r.getDirection().getZ();
		
		// l'�quation de la sph�re est (x-l)�+ (y-m)�+ (z-n)� = rayon�,
		// avec l,m,n les coordonn�es de son origine.
		double l = this.origine.getX();
		double m = this.origine.getY();
		double n = this.origine.getZ();
		
		// alors l'existence de solutions t donnant 0,1 ou 2 points de r
		// traversant la sph�re d�pend des solutions de l'�quation
		// at� + bt + c = 0, avec :
		double a = dx*dx + dy*dy + dz*dz;
		double b = 2.0 * (dx * (px - l) + dy * (py - m) + dz * (pz - n));
		double c = Math.pow(px - l, 2) + Math.pow(py - m, 2) + Math.pow(pz - n, 2) - this.rayon*this.rayon;
		
		double delta = b * b - 4 * a * c;
		if (delta >= 0.0) {
			
			// cas 2 racines ou 1 racine double:
			double t1 = (-b + Math.sqrt(delta)) / (2.0 * a);
			double t2 = (-b - Math.sqrt(delta)) / (2.0 * a);
			
			// on cherche la solution t positive la plus petite
			double t;
			// (car on cherche dans le m�me sens que celui du rayon)
			if (t1 < 0.0 && t2 < 0.0) {
				return null; // pas de solution t positive

			} else if (t1 >= 0.0 && t2 >= 0.0) {
				
				// dans le cas de la r�fraction : s'il y a deux solutions positives, on prend la plus grande
				// car la plus petite est l'origine du rayon
				// dans le cas "normal" on prend la plus petite
				double tmin = Math.min(t1, t2);
				double tmax = Math.max(t1, t2);
				
				// test cas normal
				Point intersection = new Point(px, py, pz);
				Vecteur deplacement1 = new Vecteur(dx, dy, dz);
				deplacement1 = deplacement1.multiplication(tmin);
				// on r�cup�re bien le point d'intersection � p+t*deplacement
				intersection.translater(deplacement1);
				if (intersection.equals(r.getOrigine(), 0.001)) {
					
					// le cas normal echoue, c'est de la refraction, on renvoie tmax
					intersection = new Point(px, py, pz);
					deplacement1 = new Vecteur(dx, dy, dz);
					deplacement1 = deplacement1.multiplication(tmax);
					// on r�cup�re bien le point d'intersection � p+t*deplacement
					intersection.translater(deplacement1);
					return intersection;
				} else {
					return intersection;
				}

			} else {
				t = Math.max(t1, t2); // 2 solutions de signe oppos�
			}
			Point intersection = new Point(px, py, pz);
			Vecteur deplacement = new Vecteur(dx, dy, dz);
			deplacement = deplacement.multiplication(t);
			// on r�cup�re bien le point d'intersection � p+t*deplacement
			intersection.translater(deplacement);
			if (intersection.equals(r.getOrigine(), 0.001)) {
				return null;
			} else {
				return intersection;
			}
		} else {
			// cas o� il n'y a pas de solution:
			return null;
		}
	}
	
	public Materiau getMateriau() {
		return this.properties;
	}
	
	public double getRayon() {
		return this.rayon;
	}
	
	public Point getOrigine() {
		return new Point(this.origine.getX(), this.origine.getY(), this.origine.getZ());
	}
	
	@Override
	public Point getPosition() {
		return this.origine;
	}
	
	@Override
	public Vecteur directionReflexion(Rayon r, Point p) {
		assert r != null && p != null;
		Vecteur projection = new Vecteur(r.getDirection().getX(),r.getDirection().getY(),r.getDirection().getZ());
		projection.retirerProjection(this.getNormal(p, null));
		
		Vecteur dir_reflexion = r.getDirection().soustraire(projection.multiplication(2));
		dir_reflexion = dir_reflexion.soustraire(dir_reflexion.multiplication(2));
		return dir_reflexion;
	}
	
	public Vecteur directionRefraction(Rayon r, Point p, double indiceRefractionExterieur) {
		Vecteur relatifCentreImpact = new Vecteur(this.origine, p);
		assert Math.abs(relatifCentreImpact.module() - this.rayon) < Objet3D.EPSILON;
		try {
			Plan plan = new Plan(relatifCentreImpact, p, "Plan temporaire");
			Boolean exterieurVersInterieur;
			if (r.getDirection().produitScalaire(relatifCentreImpact) < 0 ) {
				exterieurVersInterieur = true;
			} else {
				exterieurVersInterieur = false;
			}
			return plan.directionRefraction(r, ((Refraction) this.properties.getMateriau(2)).getIndiceInterieur(), exterieurVersInterieur, indiceRefractionExterieur);
		} catch (NomVideException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	@Override
	public boolean getSelfOmbre(Point impact, Rayon rayon, Lumiere lumiere) {
		assert impact != null && lumiere != null; // rayon peut �tre null pour la sph�re
		// la sph�re fait de l'ombre au point si le vecteur qui va de la
		// lumi�re vers l'impact traverse un autre point de la sph�re
		Rayon lumVersSphere = new Rayon(new Vecteur(lumiere.getCentre(), impact), lumiere.getCentre());
		Point impactReel = this.estTraversePar(lumVersSphere);
		return !((impactReel == null) || (impactReel.equals(impact,Objet3D.EPSILON)));
	}
	
	@Override
	public void translater(double dx, double dy, double dz) {
		this.origine.translater(dx, dy, dz);
	}

	@Override
	public void rotation(double rx, double ry, double rz) {
		// La rotation d'une sph�re n'implique pas de changement
	}

	@Override
	public Propriete getMateriau(int num) {
		assert 0 <= num && num < Materiau.NB_PROPRIETES;
		return this.properties.getMateriau(num);
	}

	@Override
	public String getNom() {
		return this.nom;
	}

	@Override
	public void setNom(String newNom) throws NomVideException {
		if (NomVideException.estVide(nom)) {
			throw new NomVideException();
		}
		this.nom = newNom;
	}

	@Override
	public Vecteur getNormal(Point impact, Rayon rayon) {
		assert impact != null; // rayon peut �tre null pour la sphere
		return new Vecteur(this.origine, impact);
	}
	
	@Override
	public String toString() {
		return "Sphere(" + this.nom + ")@(" + this.origine.getX() + ", " + this.origine.getY() + ", " + this.origine.getZ() + ")";
	}

	@Override
	public boolean estHorsScene(double dimension, Point centre) {
		return this.origine.distance(centre) > dimension;
	}

}
