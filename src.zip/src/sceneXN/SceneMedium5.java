package sceneXN;

import java.awt.Color;

import IG_test.FenetrePrincipale;
import elements3D.Couleur;
import elements3D.Plan;
import elements3D.Reflectivite;
import elements3D.Refraction;
import elements3D.Sphere;
import rayTracing.Camera;
import rayTracing.Lumiere;
import rayTracing.LumierePonctuelle;
import rayTracing.RayTracing;
import rayTracing.Scene;
import utilitaire.Point;
import utilitaire.Vecteur;

public class SceneMedium5 {
	public static void main(String args[]) {
		
	try {
		// Création de la scène
	    Scene scene = new Scene(3000);
	    scene.setCouleur(Color.white);
	    
	    	// Ajout d'une sphère
	    Sphere sphere1 = new Sphere(new Point(5,0,5), 2.5, "Sphere1");
	    Couleur couleur1 = (Couleur)sphere1.getMateriau(0);
	    couleur1.set(0, 255, 255); // Blanc
	    //Reflectivite reflectivite1 = (Reflectivite)sphere1.getMateriau(1);
	    //reflectivite1.setOn(false);
	    //reflectivite1.setIntensite(1);
	    //reflectivite1.setEnergie(0.5);
	    Refraction refraction1 = (Refraction)sphere1.getMateriau(2);
	    refraction1.setOn(true);
	    refraction1.setIntensite(1);
	    refraction1.setEnergie(1);
	    scene.addObjet3D(sphere1);
	    
		// Ajout d'une sphère
	    Sphere sphere2 = new Sphere(new Point(-5,2,5), 2.5, "Sphere2");
	    Couleur couleur2 = (Couleur)sphere2.getMateriau(0);
	    couleur2.set(0, 0, 255); // Rouge
	    //Reflectivite reflectivite2 = (Reflectivite)sphere2.getMateriau(1);
	   // reflectivite2.setOn(true);
	   // reflectivite2.setIntensite(0.5);
	    //reflectivite2.setEnergie(1);
	    scene.addObjet3D(sphere2);
	    
	 	
	    	// Ajout d'un plan
	    Plan plan = new Plan(new Vecteur(0,0,1), new Point(0,0,0),"plan");
	    Couleur couleur5 = (Couleur)plan.getMateriau(0);
	    couleur5.set(0, 255, 0); // Blanc
	    //Reflectivite reflectivite5 = (Reflectivite)plan.getMateriau(1);
	    //reflectivite5.setOn(true);
	    scene.addObjet3D(plan);
	    
	    	// Ajout d'une lumière
	    Lumiere lumiere1 = new LumierePonctuelle(new Point(15,0,5),new Color(255,255,255)); // Rouge
	    scene.addLumiere(lumiere1);
	    
    	// Ajout d'une lumière
	    Lumiere lumiere2 = new LumierePonctuelle(new Point(0,0,0),new Color(255,255,255)); // Rouge
	    scene.addLumiere(lumiere2);

	    
	    // Création de la caméra
	    Camera camera = new Camera(new Point(15,0,5),new Vecteur(-2,0,0),1000,1000,new Vecteur(0,0,2)); //vHaut = (0,0,10) sur l'exemple geogebra
		
	    // Lancement du ray tracing
		RayTracing raytracing = new RayTracing(scene, camera, 2, false, false);
		raytracing.lancerRayTracing();
		camera.sauvegarderImage("test4");
		//FenetrePrincipale p = new FenetrePrincipale(raytracing);
		//p.lancerFenetre();
	} catch (Exception e) {
		System.out.println("Erreur dans la gestion de la scène.");
	}
	}
}
