/**
 * 
 */
package tests;

import org.junit.*;

/**
 * @author Edgar
 *
 */
public class TestCouleur {

}
