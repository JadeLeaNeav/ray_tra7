package IG_test;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import elements3D.Objet3D;
import elements3D.Sphere;
import exception.NomVideException;
import utilitaire.Point;

import javax.swing.JSpinner;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.border.LineBorder;

public class FenetreSphere extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JSpinner x;
	private JSpinner y;
	private JSpinner z;
	private double px,py,pz;
	private String name;
	private double r;
	private JTextField nom;
	private JSpinner rayon;
	private Sphere sphere;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			FenetreSphere dialog = new FenetreSphere(null);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public FenetreSphere(Objet3D objet) {
		if (objet!= null) {
			sphere = (Sphere) objet;
			this.r = sphere.getRayon();
			Point c = sphere.getOrigine();
			px = c.getX();
			py = c.getY();
			pz = c.getZ();		
			this.name = objet.getNom();
		} else {
			this.r = 0.0;
			px = 0.0;
			py = 0.0;
			pz = 0.0;		
			this.name = "nouvelleSphere";
		}
		setBounds(100, 100, 517, 187);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 192, 203));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNom = new JLabel("Nom");
			lblNom.setBounds(135, 13, 61, 14);
			contentPanel.add(lblNom);
		}
		{
			nom = new JTextField();
			nom.setText(this.name);
			nom.setBounds(206, 10, 96, 20);
			contentPanel.add(nom);
			nom.setColumns(10);
		}
		{
			JLabel lblRayon = new JLabel("Rayon");
			lblRayon.setBounds(135, 44, 61, 14);
			contentPanel.add(lblRayon);
		}
		{
			rayon = new JSpinner();
			rayon.setBounds(206, 41, 56, 20);
			rayon.setModel(new SpinnerNumberModel(0.0, 0.0, null, 0.1));
			rayon.setValue(this.r);
			contentPanel.add(rayon);
		}
		{
			JLabel lblCentre = new JLabel("Centre");
			lblCentre.setBounds(135, 84, 61, 14);
			contentPanel.add(lblCentre);
		}
		{
			x = new JSpinner();
			x.setBounds(206, 81, 56, 20);
			x.setToolTipText("x \r\n");
			x.setModel(new SpinnerNumberModel(0.0, null, null, 0.1));
			x.setValue(px);
			contentPanel.add(x);
		}
		{
			y = new JSpinner();
			y.setBounds(288, 81, 56, 20);
			y.setModel(new SpinnerNumberModel(0.0, null, null,0.0));
			y.setValue(py);
			contentPanel.add(y);
		}
		{
			z = new JSpinner();
			z.setBounds(371, 81, 56, 20);
			z.setModel(new SpinnerNumberModel(0.0, null, null, 0.1));
			z.setValue(pz);
			contentPanel.add(z);
		}
		
		JLabel iconSphere = new JLabel("");
		iconSphere.setHorizontalAlignment(SwingConstants.CENTER);
		iconSphere.setIcon(new ImageIcon(FenetreSphere.class.getResource("/IG_test/1.png")));
		iconSphere.setBounds(10, 16, 109, 82);
		contentPanel.add(iconSphere);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBorder(new LineBorder(new Color(128, 0, 0)));
			buttonPane.setBackground(new Color(240, 128, 128));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setBackground(new Color(192, 192, 192));
				okButton.addActionListener(new ActionOK());
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Annuler");
				cancelButton.setBackground(new Color(192, 192, 192));
				cancelButton.addActionListener(new ActionAnnuler());
				cancelButton.setActionCommand("Annuler");
				buttonPane.add(cancelButton);
			}
		}
	}
	

	private class ActionOK implements ActionListener {
		
		public void actionPerformed (ActionEvent ev) {
			
		    try{
		    	r = (double) rayon.getValue();
		    	px = (double) x.getValue();
		    	py = (double) y.getValue();
		    	pz = (double) z.getValue();
		    	name = nom.getText();
		    
		    	
		    	sphere = new Sphere(new Point(px,py,pz),r, name);
		    	dispose();
	
		    }catch(NomVideException nfe){
		    	JOptionPane.showMessageDialog(null, nfe, "Veuillez remplir les cases ! ", JOptionPane.WARNING_MESSAGE);
		    }
		}
	}
	
	private class ActionAnnuler implements ActionListener {
		
		public void actionPerformed (ActionEvent ev) {
			dispose();
		}
	}
	
	public Sphere getDonnees() {
		return this.sphere;
	}
}
