package IG_test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;

import IG_test.EnregistrerScene.ActionEnregistrer;
import rayTracing.RayTracing;
import rayTracing.Scene;
import utilitaire.ObjectSaver;

public class OuvrirScene extends FenetreOuvrir {

    private RayTracing rt;
	private ListeObjets listeO;
	private ListeLumieres listeL;
	private JList<Objet> listObjets;
	private JList<Lumieres> listLumieres;
	
	public void actionouvrir() {
		ouvrir.addActionListener(new ActionOuvrir());
	}
	
	/**
	 * @param nom : nom que l'utilisateur choisit de donner � l'image.
	 * @param nrt : 
	 */
	public OuvrirScene(String nom, RayTracing nrt, ListeObjets o, ListeLumieres l, JList<Lumieres> jl,JList<Objet> jo) {
		super(nom);
		this.rt = nrt;
		this.listeL = l;
		this.listeO = o;
		this.listLumieres = jl;
		this.listObjets = jo;
		this.pack();
		this.actionouvrir();
	}
	
	/**
	 * Classe interne d'instance qui repr�sente l'observateur pour le bouton d'enregistrement
	 * de l'image.
	 */
	public class ActionOuvrir implements ActionListener {
		public void actionPerformed (ActionEvent ev) {
			
			Scene scene = ObjectSaver.openScene(text.getText());	
			if (scene == null) {
				JOptionPane.showMessageDialog(new JFrame(), "Le fichier demand� n'existe pas ou une erreur s'est produite lors de l'ouverture","Erreur ouverture Sc�ne", JOptionPane.ERROR_MESSAGE);
			} else { 
				rt.setScene(scene);
				listeO.reinitialiser(rt.getScene().getObjet3D());
				listeL.reinitialiser(rt.getScene().getLumiere());
				listLumieres.updateUI();
				listObjets.updateUI();
				System.out.printf("Sc�ne ouverte\n");
				dispose();
			}
		}
	}

}
