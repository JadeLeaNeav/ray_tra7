package IG_test;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import java.awt.Color;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import elements3D.*;
import exception.FocaleNegativeException;
import rayTracing.Camera;
import rayTracing.RayTracing;
import rayTracing.Scene;
import utilitaire.Point;
import utilitaire.Vecteur;

import javax.swing.JScrollBar;
import javax.swing.ScrollPaneConstants;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JToolBar;
import javax.swing.JToggleButton;
import javax.swing.JSlider;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;

public class FenetrePrincipale {

	private JFrame frame;
	private ListeObjets listeO;
	private ListeLumieres listeL;
	private JList<Objet> listObjets;
	private JList<Lumieres> listLumieres;
	private RayTracing rayTracing;
	private JLabel imageRT;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Scene scene = new Scene(300);
					Camera camera = new Camera(new Point(20,0,5),new Vecteur(-10,0,0),1000,1000,new Vecteur(0,0,10)); //vHaut = (0,0,10) sur l'exemple geogebra
					RayTracing raytracing = new RayTracing(scene, camera, 10, true, true);
					FenetrePrincipale window = new FenetrePrincipale(raytracing);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void lancerFenetre() {
		this.frame.setVisible(true);
	}

	/**
	 * Create the application.
	 */
	public FenetrePrincipale(RayTracing nrt) {
		this.rayTracing = nrt;
		this.listeO = new ListeObjets();
		listeO.initialiser(rayTracing.getScene().getObjet3D());
		this.listeL = new ListeLumieres();
		listeL.initialiser(rayTracing.getScene().getLumiere());
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setSize(new Dimension(1087, 674));
		frame.setResizable(false);
		frame.setBackground(new Color(240, 240, 240));
		frame.getContentPane().setForeground(new Color(102, 205, 170));
		frame.getContentPane().setBackground(new Color(32, 178, 170));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(0, 128, 128));
		frame.setJMenuBar(menuBar);
		
		JMenu menuFile = new JMenu("Fichier");
		menuFile.setMnemonic( 'F' );
		menuFile.setBackground(new Color(0, 128, 128));
		menuBar.add(menuFile);
		
		JMenuItem itemEnregistrerS = new JMenuItem("Enregistrer Sc\u00E8ne");
		itemEnregistrerS.addActionListener(new ActionEnregistrerS());
		itemEnregistrerS.setMnemonic( 'S' );
		menuFile.add( itemEnregistrerS);
		
		JMenuItem  itemOuvrir = new JMenuItem("Ouvrir ");
		itemOuvrir.addActionListener(new ActionOuvrirScene());
		itemOuvrir.setMnemonic( 'O' );
		menuFile.add(itemOuvrir);
		
		JMenuItem  itemEnregistrerI = new JMenuItem("Capture Image");
		itemEnregistrerI.addActionListener(new ActionEnregistrerI());
		itemEnregistrerI.setMnemonic( 'C' );
		menuFile.add( itemEnregistrerI);
		
		JMenu menuEditer = new JMenu("Editer");
		menuEditer.setMnemonic( 'E' );
		menuBar.add(menuEditer);
		
		JMenuItem itemAjouterO = new JMenuItem("Ajouter Objet");
		itemAjouterO.setMnemonic( 'B' );
	    itemAjouterO.addActionListener(new ActionAjouterObjet());
		menuEditer.add(itemAjouterO);
		
		JMenuItem itemAjouterL = new JMenuItem("Ajouter Lumiere");
		itemAjouterL.setMnemonic( 'L' );
		itemAjouterL.addActionListener(new ActionAjouterLumiere());
		menuEditer.add(itemAjouterL);
		
		JMenu menuAide = new JMenu("Aide");
		menuAide.setMnemonic( 'A' );
		menuBar.add(menuAide);
		
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(64, 224, 208));
		panel.setBorder(new LineBorder(new Color(64, 224, 208)));
		panel.setBackground(Color.WHITE);
		panel.setBounds(10, 71, 826, 473);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JSlider zoom = new JSlider();
		zoom.setSnapToTicks(true);
		zoom.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Zoom", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		zoom.setMaximum(1000);
		zoom.addChangeListener(new ActionZoom());
		zoom.setForeground(new Color(0, 139, 139));
		System.out.print(rayTracing.getCamera().getFocale());
		zoom.setValue((int) rayTracing.getCamera().getFocale());
		zoom.setMinimum(1);
		zoom.setMajorTickSpacing(10);
		zoom.setMinorTickSpacing(1);
		zoom.setBackground(new Color(72, 209, 204));
		zoom.setBounds(578, 415, 238, 47);
		panel.add(zoom);
		this.imageRT = new JLabel("");
		
		
		imageRT.setBounds(0, 0, 826, 473);
		panel.add(imageRT);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(72, 209, 204));
		panel_1.setBorder(new LineBorder(new Color(64, 224, 208), 1, true));
		panel_1.setBounds(846, 71, 217, 507);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JButton plusObjet = new JButton("+");
	   	plusObjet.addActionListener(new ActionAjouterObjet());
		plusObjet.setBackground(new Color(0, 139, 139));
		plusObjet.setBounds(166, 10, 41, 42);
		panel_1.add(plusObjet);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 52, 197, 125);
		panel_1.add(scrollPane);
		
		JScrollBar scrollBar = new JScrollBar();
		scrollPane.setRowHeaderView(scrollBar);
		listObjets = new JList<Objet>(this.listeO);
		scrollPane.setViewportView(listObjets);
		
		listObjets.addMouseListener(new ActionOuvrirObjet());
		listObjets.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		
		JPopupMenu popupMenuO = new JPopupMenu();
		addPopup(listObjets, popupMenuO);
		
		JMenuItem supprimerObjet = new JMenuItem("Supprimer");
		supprimerObjet.addActionListener(new ActionSupprimerObjet());
		popupMenuO.add(supprimerObjet);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_1.setBounds(10, 222, 197, 125);
		panel_1.add(scrollPane_1);
		
		JScrollBar scrollBar_1 = new JScrollBar();
		scrollPane_1.setRowHeaderView(scrollBar_1);
		listLumieres = new JList<Lumieres>(this.listeL);
		scrollPane_1.setViewportView(listLumieres);
		
		listLumieres.addMouseListener(new ActionOuvrirLumiere());
		listLumieres.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		
		JPopupMenu popupMenuL = new JPopupMenu();
		addPopup(listLumieres, popupMenuL);
		
		JMenuItem supprimerLumiere = new JMenuItem("Supprimer");
		supprimerLumiere.addActionListener(new ActionSupprimerLumiere());
		popupMenuL.add(supprimerLumiere);
		
		JButton plusLumieres = new JButton("+");
	   	plusLumieres.addActionListener(new ActionAjouterLumiere());
		plusLumieres.setBackground(new Color(0, 128, 128));
		plusLumieres.setBounds(166, 180, 41, 42);
		panel_1.add(plusLumieres);
		
		JLabel objets = new JLabel("Objets 3D");
		objets.setHorizontalAlignment(SwingConstants.CENTER);
		objets.setBackground(new Color(95, 158, 160));
		objets.setForeground(Color.BLACK);
		objets.setBounds(10, 11, 158, 42);
		panel_1.add(objets);
		
		JLabel lumiere = new JLabel("Lumi\u00E8res");
		lumiere.setHorizontalAlignment(SwingConstants.CENTER);
		lumiere.setBackground(Color.GRAY);
		lumiere.setBounds(10, 180, 158, 42);
		panel_1.add(lumiere);
		
		JButton btnParametre = new JButton("Param\u00E9trer Ray Tracing ");
		btnParametre.addActionListener(new ActionParametrer());
		btnParametre.setBackground(new Color(0, 128, 128));
		btnParametre.setBounds(10, 360, 197, 23);
		panel_1.add(btnParametre);
		
		JButton btnAnnuler = new JButton("Annuler");
		btnAnnuler.addActionListener(new ActionQuitter());
		btnAnnuler.setBackground(new Color(0, 128, 128));
		btnAnnuler.setBounds(974, 584, 89, 23);
		frame.getContentPane().add(btnAnnuler);
		
		JButton btnEnregistrerS = new JButton("Enregistrer Sc\u00E8ne");
		btnEnregistrerS.addActionListener(new ActionEnregistrerS());
		btnEnregistrerS.setBackground(new Color(0, 128, 128));
		btnEnregistrerS.setBounds(764, 584, 200, 23);
		frame.getContentPane().add(btnEnregistrerS);
		
		JButton btnEnregistrerI = new JButton("Capture Image");
		btnEnregistrerI.addActionListener(new ActionEnregistrerI());
		btnEnregistrerI.setBackground(new Color(0, 128, 128));
		btnEnregistrerI.setBounds(554, 584, 200, 23);
		frame.getContentPane().add(btnEnregistrerI);
		
		JToolBar toolBar = new JToolBar();
		toolBar.setFocusable(false);
		toolBar.setEnabled(false);
		toolBar.setFloatable(false);
		toolBar.setRollover(true);
		toolBar.setBorder(new LineBorder(new Color(64, 224, 208), 1, true));
		toolBar.setBackground(new Color(72, 209, 204));
		toolBar.setBounds(10, 21, 1053, 39);
		frame.getContentPane().add(toolBar);
		
		JButton ajouterObjet = new JButton("");
		ajouterObjet.addActionListener(new ActionAjouterObjet());
		ajouterObjet.setBackground(new Color(72, 209, 204));
		ajouterObjet.setIcon(new ImageIcon(FenetrePrincipale.class.getResource("/IG_test/objet.png")));
		toolBar.add(ajouterObjet);
		
		toolBar.addSeparator();
		
		JButton ajouterLumiere = new JButton("");
		ajouterLumiere.addActionListener(new ActionAjouterLumiere());
		ajouterLumiere.setBackground(new Color(72, 209, 204));
		ajouterLumiere.setIcon(new ImageIcon(FenetrePrincipale.class.getResource("/IG_test/lumiere.png")));
		toolBar.add(ajouterLumiere);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(64, 224, 208)));
		panel_2.setBackground(new Color(72, 209, 204));
		panel_2.setBounds(10, 547, 826, 31);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JButton lancerRT = new JButton("Lancer RayTracing");
		lancerRT.setToolTipText("Lance le ray tracing ");
		lancerRT.setBounds(10, 584, 200, 23);
		frame.getContentPane().add(lancerRT);
		lancerRT.addActionListener(new ActionLancerCalcul());
		lancerRT.setBackground(new Color(0, 128, 128));
		
	
	}
	
	public class ActionOuvrirLumiere extends MouseAdapter {
		public void mouseClicked(MouseEvent evt) {
	        if (evt.getClickCount() == 2) {
				FenetreLumiere lux = new FenetreLumiere(rayTracing,listeL,listLumieres,listLumieres.getSelectedValue());
				lux.setVisible(true);
	        } else if (evt.getClickCount() == 3) {
				FenetreLumiere lux = new FenetreLumiere(rayTracing,listeL,listLumieres,listLumieres.getSelectedValue());
				lux.setVisible(true);
	        }
		}
	}
	
	public class ActionOuvrirObjet extends MouseAdapter {
		public void mouseClicked(MouseEvent evt) {
	        if (evt.getClickCount() == 2) {
				FenetreObjet objet = new FenetreObjet(rayTracing,listeO,listObjets,listObjets.getSelectedValue());
				objet.setVisible(true);
	        } else if (evt.getClickCount() == 3) {
				FenetreObjet objet = new FenetreObjet(rayTracing,listeO,listObjets,listObjets.getSelectedValue());
				objet.setVisible(true);
	        }
		}
	}
	
	public class ActionSupprimerObjet implements ActionListener {
		
		public void actionPerformed(ActionEvent ev) {
			Object[] options = {"Oui", "Non"};
			int n = JOptionPane.showOptionDialog(new JFrame(),
		    		"�tes-vous s�re de vouloir supprimer cet objet : " + listObjets.getSelectedValue().getNom(),
		    		"Supprimer une lumi�re",
		    		JOptionPane.WARNING_MESSAGE, 
		    	    JOptionPane.YES_NO_OPTION,
		    	    null,    
		    	    options,  
		    	    options[0]); 
		    	if (n == 0) {
					int io = listObjets.getSelectedIndex();
					rayTracing.getScene().getObjet3D().remove(io);
					listeO.getObjets().remove(io);
					listObjets.updateUI();
					if(imageRT.getIcon() != null) {
						rayTracing.lancerRayTracing();
						imageRT.setIcon(new ImageIcon(rayTracing.getCamera().creerImage()));
					}
		    	}
		}
	}
	
	public class ActionSupprimerLumiere implements ActionListener {
		
		public void actionPerformed(ActionEvent ev) {
			Object[] options = {"Oui", "Non"};
			int n = JOptionPane.showOptionDialog(new JFrame(),
		    		"�tes-vous s�re de vouloir supprimer la lumiere : " + listLumieres.getSelectedValue().getNom(),
		    		"Supprimer une lumi�re",
		    		JOptionPane.WARNING_MESSAGE, 
		    	    JOptionPane.YES_NO_OPTION,
		    	    null,    
		    	    options,  
		    	    options[0]); 
		    	if (n == 0) {
					int il = listLumieres.getSelectedIndex();
					rayTracing.getScene().getLumiere().remove(il);
					listeL.getObjets().remove(il);
					listLumieres.updateUI();
					if(imageRT.getIcon() != null) {
						rayTracing.lancerRayTracing();
						imageRT.setIcon(new ImageIcon(rayTracing.getCamera().creerImage()));
					}
		    	}
			

		}
	}
	
	public class ActionEnregistrerI implements ActionListener {
		
		public void actionPerformed(ActionEvent ev) {
			EnregistrerImage enregistrer = new EnregistrerImage( "Enregistrer Capture Image", rayTracing);
			enregistrer.setVisible(true);
			
		}
	}
	
	public class ActionEnregistrerS implements ActionListener {
		
		public void actionPerformed(ActionEvent ev) {
			EnregistrerScene enregistrer = new EnregistrerScene( "Enregistrer Scene", rayTracing);
			enregistrer.setVisible(true);
			
		}
	}
	
	public class ActionLancerCalcul implements ActionListener {
		public void actionPerformed(ActionEvent ev) {
			System.out.printf("Calcul lanc� ...\n");
			rayTracing.lancerRayTracing();
			imageRT.setIcon(new ImageIcon(rayTracing.getCamera().creerImage()));
			System.out.printf("Calcul Termin� \n");
		}
	}
	
	public class ActionAjouterObjet implements ActionListener {
		public void actionPerformed(ActionEvent ev) {
			FenetreObjet objet = new FenetreObjet(rayTracing,listeO,listObjets);
			objet.setVisible(true);
		}
	}
	
	public class ActionAjouterLumiere implements ActionListener {
		public void actionPerformed(ActionEvent ev) {
			FenetreLumiere lux = new FenetreLumiere(rayTracing,listeL,listLumieres);
			lux.setVisible(true);
		}
	}
	
	public class ActionOuvrirScene implements ActionListener {
		public void actionPerformed(ActionEvent ev) {
			OuvrirScene ouvrir = new OuvrirScene( "Enregistrer Scene", rayTracing,listeO,listeL,listLumieres,listObjets);
			ouvrir.setVisible(true);
			
		}
	}
	
	public class ActionParametrer implements ActionListener {
		public void actionPerformed(ActionEvent ev) {
			Parametrage parametre = new Parametrage(rayTracing);
			parametre.setVisible(true);
		}
	}
	
	public class ActionQuitter implements ActionListener {
		public void actionPerformed(ActionEvent ev) {
			System.exit(0);
		}
	}
	
	public class ActionZoom implements ChangeListener {
		public void stateChanged(ChangeEvent e) {
		    JSlider source = (JSlider)e.getSource();
		    if (!source.getValueIsAdjusting()) {
		        double i = 1 + (double)source.getValue()/100;
		        try {
					rayTracing.getCamera().setFocale(i);
					if (imageRT != null && imageRT.getIcon() != null) {
						rayTracing.lancerRayTracing();
						imageRT.setIcon(new ImageIcon(rayTracing.getCamera().creerImage()));
					}
				} catch (FocaleNegativeException e1) {
					e1.printStackTrace();
				}
		    }
		}
	}
	
	
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
